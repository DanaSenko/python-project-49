### Hexlet tests and linter status:
[![Actions Status](https://github.com/DanaSenko/python-project-49/actions/workflows/hexlet-check.yml/badge.svg)](https://github.com/DanaSenko/python-project-49/actions)

![Maintainability]<a href="https://codeclimate.com/github/DanaSenko/python-project-49/maintainability"><img src="https://api.codeclimate.com/v1/badges/d9ad3f097a40f8c63412/maintainability" /></a>